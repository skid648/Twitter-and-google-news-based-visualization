<?php

	$servername = "localhost";
	$username = "root";
	$password = "1q2w3e4r";
	$dbname = "xoria";

?>